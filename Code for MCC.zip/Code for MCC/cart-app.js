class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function CartApp() {
  try {
    const [cartItems, setCartItems] = React.useState([]);
    const [showCheckout, setShowCheckout] = React.useState(false);
    const [formData, setFormData] = React.useState({name: '', phone: '', email: '', farm: '', deliveryAddress: '', notes: ''});
    const [submitted, setSubmitted] = React.useState(false);

    React.useEffect(() => {
      const savedCart = localStorage.getItem('mccCart');
      if (savedCart) {
        setCartItems(JSON.parse(savedCart));
      }
    }, []);

    const updateQuantity = (index, newQty) => {
      if (newQty < 1) return;
      const updated = [...cartItems];
      updated[index].quantity = newQty;
      setCartItems(updated);
      localStorage.setItem('mccCart', JSON.stringify(updated));
    };

    const removeItem = (index) => {
      const updated = cartItems.filter((_, i) => i !== index);
      setCartItems(updated);
      localStorage.setItem('mccCart', JSON.stringify(updated));
    };

    const calculateTotal = () => {
      return cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    };

    const handleSubmit = async (e) => {
      e.preventDefault();
      
      const orderData = {
        customer: formData,
        items: cartItems,
        total: calculateTotal(),
        orderDate: new Date().toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' })
      };
      
      // Prepare email content
      const emailSubject = `New Order from ${formData.name}`;
      const emailBody = `
New Order Received

Customer Details:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Email: ${formData.email || 'Not provided'}
- Farm Location: ${formData.farm}
- Delivery Address: ${formData.deliveryAddress}

Order Items:
${cartItems.map(item => `- ${item.name} (${item.size}) x ${item.quantity} = R ${(item.price * item.quantity).toFixed(2)}`).join('\n')}

Total Amount: R ${calculateTotal().toFixed(2)}

Additional Notes: ${formData.notes || 'None'}

Order Date: ${orderData.orderDate}
      `.trim();
      
      // Send to multiple email addresses
      const emailRecipients = [
        'mccfertilizers@gmail.com',
        'info@mccfertilizers.co.za',
        'orders@mccfertilizers.co.za',
        'vusi.mnguni@mccfertilizers.co.za',
        'francis.moyo1975@gmail.com'
      ];
      
      const mailtoLink = `mailto:${emailRecipients.join(',')}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      
      // Prepare WhatsApp message
      const whatsappMessage = `*New Order from MCC Fertilizers Website*\n\n*Customer:* ${formData.name}\n*Phone:* ${formData.phone}\n*Farm:* ${formData.farm}\n\n*Order Items:*\n${cartItems.map(item => `${item.name} (${item.size}) x${item.quantity} - R${(item.price * item.quantity).toFixed(2)}`).join('\n')}\n\n*Total: R${calculateTotal().toFixed(2)}*\n\n*Delivery Address:*\n${formData.deliveryAddress}${formData.notes ? `\n\n*Notes:* ${formData.notes}` : ''}`;
      
      const whatsappLink = `https://wa.me/27764206125?text=${encodeURIComponent(whatsappMessage)}`;
      
      // Open email client
      window.open(mailtoLink, '_blank');
      
      // Open WhatsApp after a short delay
      setTimeout(() => {
        window.open(whatsappLink, '_blank');
      }, 500);
      
      console.log('Order submitted:', orderData);
      setSubmitted(true);
      localStorage.removeItem('mccCart');
      setTimeout(() => window.location.href = 'index.html', 3000);
    };

    const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
    };

    if (submitted) {
      return (
        <div className="min-h-screen" data-name="cart-app" data-file="cart-app.js">
          <Header />
          <div className="py-24 px-4">
            <div className="max-w-2xl mx-auto text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="icon-check text-4xl text-green-600"></div>
              </div>
              <h1 className="text-3xl font-bold text-[var(--primary-color)] mb-4">Order Placed Successfully!</h1>
              <p className="text-lg text-[var(--text-light)] mb-6">Thank you for your order. We'll contact you shortly to confirm details and arrange delivery.</p>
              <p className="text-sm text-[var(--text-light)]">Redirecting to home page...</p>
            </div>
          </div>
          <Footer />
        </div>
      );
    }

    return (
      <div className="min-h-screen" data-name="cart-app" data-file="cart-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-8">Shopping Cart</h1>
            
            {cartItems.length === 0 ? (
              <div className="text-center py-16">
                <div className="icon-shopping-cart text-6xl text-gray-300 mb-4"></div>
                <p className="text-xl text-[var(--text-light)] mb-6">Your cart is empty</p>
                <a href="products.html" className="btn-primary">Browse Products</a>
              </div>
            ) : !showCheckout ? (
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-4">
                  {cartItems.map((item, index) => (
                    <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 flex items-center gap-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-[var(--primary-color)] mb-1">{item.name}</h3>
                        <p className="text-sm text-[var(--text-light)] mb-2">{item.size}</p>
                        <p className="text-xl font-bold text-[var(--accent-color)]">R {item.price.toFixed(2)}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <button onClick={() => updateQuantity(index, item.quantity - 1)} className="w-8 h-8 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100">
                          <div className="icon-minus text-sm"></div>
                        </button>
                        <span className="w-12 text-center font-semibold">{item.quantity}</span>
                        <button onClick={() => updateQuantity(index, item.quantity + 1)} className="w-8 h-8 rounded border border-gray-300 flex items-center justify-center hover:bg-gray-100">
                          <div className="icon-plus text-sm"></div>
                        </button>
                      </div>
                      <button onClick={() => removeItem(index)} className="text-red-500 hover:text-red-700">
                        <div className="icon-trash-2 text-xl"></div>
                      </button>
                    </div>
                  ))}
                </div>
                
                <div className="lg:col-span-1">
                  <div className="bg-[var(--bg-light)] rounded-lg p-6 sticky top-24">
                    <h2 className="text-xl font-bold text-[var(--primary-color)] mb-4">Order Summary</h2>
                    <div className="space-y-2 mb-4 pb-4 border-b border-gray-300">
                      {cartItems.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-[var(--text-light)]">{item.name} x{item.quantity}</span>
                          <span className="font-semibold">R {(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between text-lg font-bold mb-6">
                      <span>Total:</span>
                      <span className="text-[var(--accent-color)]">R {calculateTotal().toFixed(2)}</span>
                    </div>
                    <button onClick={() => setShowCheckout(true)} className="btn-primary w-full">Proceed to Checkout</button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2">
                  <form onSubmit={handleSubmit} className="bg-white border border-gray-200 rounded-lg p-8">
                    <h2 className="text-2xl font-bold text-[var(--primary-color)] mb-6">Delivery Details</h2>
                    
                    <div className="mb-6">
                      <label className="block text-[var(--text-dark)] font-semibold mb-2">Full Name *</label>
                      <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                    </div>

                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <label className="block text-[var(--text-dark)] font-semibold mb-2">Phone Number *</label>
                        <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                      </div>
                      <div>
                        <label className="block text-[var(--text-dark)] font-semibold mb-2">Email</label>
                        <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                      </div>
                    </div>

                    <div className="mb-6">
                      <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Location *</label>
                      <input type="text" name="farm" value={formData.farm} onChange={handleChange} required placeholder="e.g., Empangeni, KZN" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                    </div>

                    <div className="mb-6">
                      <label className="block text-[var(--text-dark)] font-semibold mb-2">Delivery Address *</label>
                      <textarea name="deliveryAddress" value={formData.deliveryAddress} onChange={handleChange} required rows="3" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
                    </div>

                    <div className="mb-6">
                      <label className="block text-[var(--text-dark)] font-semibold mb-2">Additional Notes</label>
                      <textarea name="notes" value={formData.notes} onChange={handleChange} rows="3" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
                    </div>

                    <div className="flex gap-4">
                      <button type="button" onClick={() => setShowCheckout(false)} className="btn-secondary flex-1">Back to Cart</button>
                      <button type="submit" className="btn-primary flex-1">Place Order</button>
                    </div>
                  </form>
                </div>
                
                <div className="lg:col-span-1">
                  <div className="bg-[var(--bg-light)] rounded-lg p-6 sticky top-24">
                    <h2 className="text-xl font-bold text-[var(--primary-color)] mb-4">Order Summary</h2>
                    <div className="space-y-2 mb-4 pb-4 border-b border-gray-300">
                      {cartItems.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm">
                          <span className="text-[var(--text-light)]">{item.name} x{item.quantity}</span>
                          <span className="font-semibold">R {(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-[var(--accent-color)]">R {calculateTotal().toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('CartApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><CartApp /></ErrorBoundary>);
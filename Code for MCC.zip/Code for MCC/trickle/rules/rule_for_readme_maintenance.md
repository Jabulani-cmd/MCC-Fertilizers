When project updates occur
- Check if README.md needs updating when:
  - New pages or features are added
  - Contact information changes
  - Design system or color scheme updates
  - Major functionality changes
  - New sections or components are introduced
- Update the README.md in trickle/notes/ accordingly
- Keep the README concise but comprehensive
- Include all important project information
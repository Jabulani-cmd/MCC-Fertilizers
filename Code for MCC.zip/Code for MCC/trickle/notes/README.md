# MCC Fertilizers Website

## Overview
A professional website for MCC Fertilizers, a company specializing in supplying fertilizers and chemicals exclusively for sugarcane farming in KwaZulu-Natal, South Africa.

## Pages
1. **Home** - Hero carousel with company introduction and CTAs
2. **About Us** - Company history and director profile
3. **Why Us** - Value propositions and competitive advantages
4. **Products** - Filterable catalog of fertilizers and chemicals
5. **Place Order** - Order form for product purchases
6. **Request a Quote** - Form for bulk orders and consultations
7. **Contact Us** - Contact information, form, and location map

## Design System
- **Primary Color**: Dark Green (#2d5f1e) - Agriculture theme
- **Secondary Color**: Light Green (#8fbc5a) - Growth and vitality
- **Accent Color**: Orange (#d97706) - Call to action
- **Typography**: Inter font family
- **Icons**: Lucide icon library

## Contact Information
- **Address**: UMoba House, 1 Blesbok Street, Empangeni Rail 3910, KZN
- **Landline**: +27 35 772 1205
- **Mobile**: +27 76 420 6125 / +27 61 506 2116
- **WhatsApp**: +27 76 420 6125
- **Email**: info@mccfertilizers.co.za

## Features
- Responsive design for all devices
- Auto-rotating hero carousel
- Product category filtering
- WhatsApp integration (fixed button)
- Google Maps integration
- Contact and order forms

## Technology Stack
- React 18
- TailwindCSS
- Lucide Icons
- Google Maps Embed API
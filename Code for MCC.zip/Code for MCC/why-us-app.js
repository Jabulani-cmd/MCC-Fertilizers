class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function WhyUsApp() {
  try {
    const reasons = [
      { icon: 'award', title: 'Premium Quality Products', description: 'We supply only the highest quality fertilizers and chemicals specifically formulated for sugarcane cultivation.' },
      { icon: 'map-pin', title: 'Local Expertise', description: 'Deep understanding of KwaZulu-Natal soil conditions and climate patterns for optimal farming results.' },
      { icon: 'truck', title: 'Reliable Delivery', description: 'Timely and dependable delivery service throughout the KwaZulu-Natal region.' },
      { icon: 'users', title: 'Expert Consultation', description: 'Professional agricultural advice and ongoing support from experienced farming specialists.' },
      { icon: 'shield-check', title: 'Trusted Reputation', description: 'Years of proven track record serving the sugarcane farming community.' },
      { icon: 'headset', title: 'Customer Support', description: 'Dedicated support team available to assist with your farming needs and questions.' }
    ];

    return (
      <div className="min-h-screen" data-name="why-us-app" data-file="why-us-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-6 text-center">Why Choose MCC Fertilizers</h1>
            <p className="text-lg text-[var(--text-light)] text-center mb-12 max-w-3xl mx-auto">
              Discover what sets us apart as the preferred partner for sugarcane farmers across KwaZulu-Natal.
            </p>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {reasons.map((reason, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                  <div className="w-14 h-14 rounded-lg bg-[var(--secondary-color)] flex items-center justify-center mb-4">
                    <div className={`icon-${reason.icon} text-2xl text-white`}></div>
                  </div>
                  <h3 className="text-xl font-bold text-[var(--primary-color)] mb-3">{reason.title}</h3>
                  <p className="text-[var(--text-light)]">{reason.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('WhyUsApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><WhyUsApp /></ErrorBoundary>);

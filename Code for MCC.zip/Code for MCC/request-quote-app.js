class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function RequestQuoteApp() {
  try {
    const [formData, setFormData] = React.useState({name: '', phone: '', email: '', farm: '', farmSize: '', productInterest: '', message: ''});
    const [submitted, setSubmitted] = React.useState(false);

    const handleSubmit = (e) => {
      e.preventDefault();
      
      const emailSubject = `Quote Request from ${formData.name}`;
      const emailBody = `
New Quote Request

Customer Details:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Email: ${formData.email || 'Not provided'}
- Farm Location: ${formData.farm}
- Farm Size: ${formData.farmSize || 'Not specified'}
- Product Interest: ${formData.productInterest}

Message:
${formData.message}

Request Date: ${new Date().toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' })}
      `.trim();
      
      const emailRecipients = [
        'mccfertilizers@gmail.com',
        'info@mccfertilizers.co.za',
        'francis.moyo1975@gmail.com'
      ];
      
      const mailtoLink = `mailto:${emailRecipients.join(',')}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoLink, '_blank');
      
      console.log('Quote request submitted:', formData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    };

    const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
    };

    return (
      <div className="min-h-screen" data-name="request-quote-app" data-file="request-quote-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-6 text-center">Request a Quote</h1>
            <p className="text-lg text-[var(--text-light)] text-center mb-12">Need a customized quote for bulk orders or farming consultation? Fill out the form and our team will contact you.</p>
            
            {submitted && (
              <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">Quote request submitted! We'll get back to you shortly.</div>
            )}

            <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-8">
              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Full Name *</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Phone Number *</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Email</label>
                  <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Location *</label>
                  <input type="text" name="farm" value={formData.farm} onChange={handleChange} required placeholder="e.g., Empangeni, KZN" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Size (Hectares)</label>
                  <input type="text" name="farmSize" value={formData.farmSize} onChange={handleChange} placeholder="e.g., 50 hectares" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Product Interest *</label>
                <select name="productInterest" value={formData.productInterest} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]">
                  <option value="">Select category</option>
                  <option value="Fertilizers">Fertilizers</option>
                  <option value="Chemicals">Chemicals</option>
                  <option value="Both">Both Fertilizers and Chemicals</option>
                  <option value="Consultation">Farming Consultation</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Message *</label>
                <textarea name="message" value={formData.message} onChange={handleChange} required rows="5" placeholder="Tell us about your specific needs..." className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
              </div>

              <button type="submit" className="btn-primary w-full">Request Quote</button>
            </form>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('RequestQuoteApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><RequestQuoteApp /></ErrorBoundary>);

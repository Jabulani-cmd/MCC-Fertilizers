class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function AboutApp() {
  try {
    return (
      <div className="min-h-screen" data-name="about-app" data-file="about-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-gradient-to-br from-green-50 to-emerald-50">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-8 text-center">About MCC Fertilizers</h1>
            <p className="text-lg text-[var(--text-light)] mb-6">
              MCC Fertilizers is a leading supplier of agricultural products dedicated exclusively to the sugarcane farming industry in KwaZulu-Natal, South Africa. With years of experience and deep understanding of local farming conditions, we have become a trusted partner for farmers throughout the region.
            </p>
            <p className="text-lg text-[var(--text-light)] mb-6">
              Our mission is to provide high-quality fertilizers and chemicals that help sugarcane farmers maximize their yields while maintaining sustainable farming practices. We understand the unique challenges faced by KZN farmers and are committed to delivering solutions that work.
            </p>
            <p className="text-lg text-[var(--text-light)] mb-8">
              Located in Empangeni, we are strategically positioned to serve the heart of KwaZulu-Natal's sugarcane farming region. Our team combines technical expertise with practical farming knowledge to provide comprehensive support to our clients.
            </p>

            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <div className="bg-gradient-to-br from-[var(--secondary-color)] to-[var(--primary-color)] p-6 rounded-lg text-center text-white shadow-lg">
                <div className="icon-users text-4xl mb-3"></div>
                <div className="text-3xl font-bold mb-2">500+</div>
                <div className="text-sm">Satisfied Farmers</div>
              </div>
              <div className="bg-gradient-to-br from-[var(--accent-color)] to-orange-600 p-6 rounded-lg text-center text-white shadow-lg">
                <div className="icon-package text-4xl mb-3"></div>
                <div className="text-3xl font-bold mb-2">15+</div>
                <div className="text-sm">Premium Products</div>
              </div>
              <div className="bg-gradient-to-br from-[var(--secondary-color)] to-[var(--primary-color)] p-6 rounded-lg text-center text-white shadow-lg">
                <div className="icon-award text-4xl mb-3"></div>
                <div className="text-3xl font-bold mb-2">20+</div>
                <div className="text-sm">Years Experience</div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-gradient-to-br from-amber-50 to-orange-50">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[var(--primary-color)] mb-3">Meet Our Director</h2>
              <p className="text-[var(--text-light)]">Leadership rooted in agricultural excellence</p>
            </div>
            
            <div className="bg-white rounded-lg shadow-xl p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--secondary-color)] opacity-10 rounded-full -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-[var(--primary-color)] opacity-10 rounded-full -ml-24 -mb-24"></div>
              
              <div className="relative flex flex-col md:flex-row gap-8 items-center">
                <div className="w-64 h-80 rounded-lg overflow-hidden flex-shrink-0 shadow-xl border-4 border-[var(--secondary-color)] transform hover:scale-105 transition-transform duration-300">
                  <img src="https://app.trickle.so/storage/public/images/usr_172cb91f60000001/aa791365-4681-405f-a10f-c2a70cf66cc7.jpeg" alt="Mr. V. Mnguni" className="w-full h-full object-cover" style={{objectPosition: 'center 35%'}} />
                </div>
                
                <div className="flex-1">
                  <div className="mb-4">
                    <h3 className="text-3xl font-bold text-[var(--primary-color)] mb-1">Mr. V. Mnguni</h3>
                    <p className="text-[var(--accent-color)] font-semibold">Founder & Director</p>
                  </div>
                  
                  <p className="text-[var(--text-light)] mb-4 leading-relaxed">
                    With over two decades of experience in agricultural supply and deep roots in KwaZulu-Natal's farming community, our director has built MCC Fertilizers on a foundation of trust, quality, and commitment to farmer success.
                  </p>
                  
                  <p className="text-[var(--text-light)] mb-6 leading-relaxed">
                    Their leadership and vision have established MCC Fertilizers as a reliable partner for sugarcane farmers, combining industry expertise with genuine care for the farming community's prosperity and sustainable growth.
                  </p>

                  <div className="flex flex-wrap gap-4">
                    <div className="flex items-center gap-2 bg-[var(--bg-light)] px-4 py-2 rounded-lg">
                      <div className="icon-briefcase text-lg text-[var(--primary-color)]"></div>
                      <span className="text-sm font-medium">20+ Years Industry</span>
                    </div>
                    <div className="flex items-center gap-2 bg-[var(--bg-light)] px-4 py-2 rounded-lg">
                      <div className="icon-heart text-lg text-[var(--primary-color)]"></div>
                      <span className="text-sm font-medium">Community Focused</span>
                    </div>
                    <div className="flex items-center gap-2 bg-[var(--bg-light)] px-4 py-2 rounded-lg">
                      <div className="icon-target text-lg text-[var(--primary-color)]"></div>
                      <span className="text-sm font-medium">Results Driven</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('AboutApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><AboutApp /></ErrorBoundary>);
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function ContactApp() {
  try {
    const [formData, setFormData] = React.useState({name: '', email: '', subject: '', message: ''});
    const [submitted, setSubmitted] = React.useState(false);

    const handleSubmit = (e) => {
      e.preventDefault();
      
      const emailSubject = `Contact Form: ${formData.subject}`;
      const emailBody = `
Contact Form Submission

Customer Details:
- Name: ${formData.name}
- Email: ${formData.email}
- Subject: ${formData.subject}

Message:
${formData.message}

Submitted: ${new Date().toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' })}
      `.trim();
      
      const emailRecipients = [
        'mccfertilizers@gmail.com',
        'info@mccfertilizers.co.za',
        'francis.moyo1975@gmail.com'
      ];
      
      const mailtoLink = `mailto:${emailRecipients.join(',')}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoLink, '_blank');
      
      console.log('Contact form submitted:', formData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    };

    const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
    };

    const whatsappUrl = 'https://wa.me/27764206125?text=Hello%20MCC%20Fertilizers';

    return (
      <div className="min-h-screen" data-name="contact-app" data-file="contact-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-12 text-center">Contact Us</h1>
            
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl font-bold text-[var(--primary-color)] mb-6">Get in Touch</h2>
                
                <div className="space-y-6 mb-8">
                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-lg bg-[var(--secondary-color)] flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-map-pin text-xl text-white"></div>
                    </div>
                    <div>
                      <h3 className="font-bold text-[var(--text-dark)] mb-1">Address</h3>
                      <p className="text-[var(--text-light)]">UMoba House, 1 Blesbok Street<br/>Empangeni Rail 3910<br/>KwaZulu-Natal, South Africa</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-lg bg-[var(--secondary-color)] flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-phone text-xl text-white"></div>
                    </div>
                    <div>
                      <h3 className="font-bold text-[var(--text-dark)] mb-1">Phone</h3>
                      <p className="text-[var(--text-light)]">Landline: +27 35 772 1205</p>
                      <p className="text-[var(--text-light)]">Mobile: +27 76 420 6125</p>
                      <p className="text-[var(--text-light)]">Mobile: +27 61 506 2116</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-lg bg-[var(--secondary-color)] flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-mail text-xl text-white"></div>
                    </div>
                    <div>
                      <h3 className="font-bold text-[var(--text-dark)] mb-1">Email</h3>
                      <p className="text-[var(--text-light)]">info@mccfertilizers.co.za</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 rounded-lg bg-green-500 flex items-center justify-center mr-4 flex-shrink-0">
                      <div className="icon-message-circle text-xl text-white"></div>
                    </div>
                    <div>
                      <h3 className="font-bold text-[var(--text-dark)] mb-1">WhatsApp</h3>
                      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:text-green-700 font-medium">+27 76 420 6125 - Click to chat</a>
                    </div>
                  </div>
                </div>

                <div className="bg-[var(--bg-light)] p-6 rounded-lg">
                  <h3 className="font-bold text-[var(--text-dark)] mb-3">Business Hours</h3>
                  <p className="text-[var(--text-light)]">Monday - Friday: 8:00 AM - 5:00 PM</p>
                  <p className="text-[var(--text-light)]">Saturday: 8:00 AM - 1:00 PM</p>
                  <p className="text-[var(--text-light)]">Sunday: Closed</p>
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-[var(--primary-color)] mb-6">Send Us a Message</h2>
                
                {submitted && (
                  <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">Message sent! We'll get back to you soon.</div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-[var(--text-dark)] font-semibold mb-2">Name *</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                  </div>

                  <div>
                    <label className="block text-[var(--text-dark)] font-semibold mb-2">Email *</label>
                    <input type="email" name="email" value={formData.email} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                  </div>

                  <div>
                    <label className="block text-[var(--text-dark)] font-semibold mb-2">Subject *</label>
                    <input type="text" name="subject" value={formData.subject} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                  </div>

                  <div>
                    <label className="block text-[var(--text-dark)] font-semibold mb-2">Message *</label>
                    <textarea name="message" value={formData.message} onChange={handleChange} required rows="5" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
                  </div>

                  <button type="submit" className="btn-primary w-full">Send Message</button>
                </form>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-[var(--bg-light)]">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-2xl font-bold text-[var(--primary-color)] mb-6 text-center">Find Us on the Map</h2>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3524.0!2d31.8936!3d-28.7442!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjjCsDQ0JzM5LjEiUyAzMcKwNTMnMzcuMCJF!5e0!3m2!1sen!2sza!4v1234567890"
                width="100%"
                height="450"
                style={{border: 0}}
                allowFullScreen=""
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('ContactApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><ContactApp /></ErrorBoundary>);
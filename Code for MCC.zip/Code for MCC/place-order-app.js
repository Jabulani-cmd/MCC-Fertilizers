class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function PlaceOrderApp() {
  try {
    const [formData, setFormData] = React.useState({name: '', phone: '', email: '', farm: '', product: '', quantity: '', notes: ''});
    const [submitted, setSubmitted] = React.useState(false);

    const handleSubmit = (e) => {
      e.preventDefault();
      console.log('Order submitted:', formData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    };

    const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
    };

    return (
      <div className="min-h-screen" data-name="place-order-app" data-file="place-order-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-6 text-center">Place Your Order</h1>
            <p className="text-lg text-[var(--text-light)] text-center mb-12">Fill out the form below to place your order. We'll contact you to confirm details and arrange delivery.</p>
            
            {submitted && (
              <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">Order submitted successfully! We'll contact you soon.</div>
            )}

            <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-8">
              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Full Name *</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Phone Number *</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Email</label>
                  <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Location *</label>
                <input type="text" name="farm" value={formData.farm} onChange={handleChange} required placeholder="e.g., Empangeni, KZN" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Product *</label>
                  <select name="product" value={formData.product} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]">
                    <option value="">Select product</option>
                    <option value="UREA - 50kg">UREA - 50kg</option>
                    <option value="234 - 50kg">234 - 50kg</option>
                    <option value="515 - 50kg">515 - 50kg</option>
                    <option value="101 - 50kg">101 - 50kg</option>
                    <option value="LAN - 50kg">LAN - 50kg</option>
                    <option value="MAP - 50kg">MAP - 50kg</option>
                    <option value="ACCETOCHLOOR - 20L">ACCETOCHLOOR - 20L</option>
                    <option value="ACCETOCHLOOR - 5L">ACCETOCHLOOR - 5L</option>
                    <option value="AMETRYN - 20L">AMETRYN - 20L</option>
                    <option value="AMETRYN - 5L">AMETRYN - 5L</option>
                    <option value="DIURON - 20L">DIURON - 20L</option>
                    <option value="DIURON - 5L">DIURON - 5L</option>
                    <option value="MSMA - 20L">MSMA - 20L</option>
                    <option value="MSMA - 5L">MSMA - 5L</option>
                    <option value="PARAQUART - 20L">PARAQUART - 20L</option>
                    <option value="PARAQUART - 5L">PARAQUART - 5L</option>
                    <option value="CLEAROUT - 20L">CLEAROUT - 20L</option>
                    <option value="CLEAROUT - 5L">CLEAROUT - 5L</option>
                    <option value="FARMURON - 20L">FARMURON - 20L</option>
                    <option value="FARMURON - 5L">FARMURON - 5L</option>
                    <option value="GUILLOTINE - Packet 50g">GUILLOTINE - Packet 50g</option>
                    <option value="GUILLOTINE - Box of 10">GUILLOTINE - Box of 10</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Quantity *</label>
                  <input type="number" name="quantity" value={formData.quantity} onChange={handleChange} required min="1" placeholder="Number of units" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Additional Notes</label>
                <textarea name="notes" value={formData.notes} onChange={handleChange} rows="4" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
              </div>

              <button type="submit" className="btn-primary w-full">Submit Order</button>
            </form>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('PlaceOrderApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><PlaceOrderApp /></ErrorBoundary>);
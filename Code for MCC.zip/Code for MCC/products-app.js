class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function ProductsApp() {
  try {
    const [category, setCategory] = React.useState('all');
    
    const addToCart = (product) => {
      let price = 0;
      let size = '';
      
      if (product.price) {
        price = parseFloat(product.price.replace(/[R\s,]/g, ''));
        size = product.unit;
      } else if (product.price20L) {
        price = parseFloat(product.price20L.replace(/[R\s,]/g, ''));
        size = '20 Litres';
      } else if (product.pricePacket) {
        price = parseFloat(product.pricePacket.replace(/[R\s,]/g, ''));
        size = product.unitPacket;
      }
      
      const cartItem = {
        name: product.name,
        price: price,
        size: size,
        quantity: 1
      };
      
      const existingCart = JSON.parse(localStorage.getItem('mccCart') || '[]');
      const existingIndex = existingCart.findIndex(item => item.name === cartItem.name && item.size === cartItem.size);
      
      if (existingIndex > -1) {
        existingCart[existingIndex].quantity += 1;
      } else {
        existingCart.push(cartItem);
      }
      
      localStorage.setItem('mccCart', JSON.stringify(existingCart));
      window.location.href = 'cart.html';
    };
    
    const products = [
      { id: 1, name: 'UREA', category: 'fertilizers', price: 'R 650.00', unit: '50kg', description: 'High nitrogen content for vigorous vegetative growth' },
      { id: 2, name: '234', category: 'fertilizers', price: 'R 700.00', unit: '50kg', description: 'Balanced NPK formula for optimal sugarcane growth' },
      { id: 3, name: '515', category: 'fertilizers', price: 'R 650.00', unit: '50kg', description: 'Complete nutrient solution for healthy cane development' },
      { id: 4, name: '101', category: 'fertilizers', price: 'R 650.00', unit: '50kg', description: 'Essential nutrients for sugarcane cultivation' },
      { id: 5, name: 'LAN', category: 'fertilizers', price: 'R 550.00', unit: '50kg', description: 'Limestone Ammonium Nitrate for nitrogen supply' },
      { id: 6, name: 'MAP', category: 'fertilizers', price: 'R 825.00', unit: '50kg', description: 'Monoammonium Phosphate for phosphorus nutrition' },
      { id: 7, name: 'ACCETOCHLOOR', category: 'chemicals', price20L: 'R 2,100.00', price5L: 'R 900.00', description: 'Pre-emergence herbicide for weed control' },
      { id: 8, name: 'AMETRYN', category: 'chemicals', price20L: 'R 2,240.00', price5L: 'R 600.00', description: 'Selective herbicide for sugarcane' },
      { id: 9, name: 'DIURON', category: 'chemicals', price20L: 'R 3,400.00', price5L: 'R 900.00', description: 'Long-lasting residual herbicide' },
      { id: 10, name: 'MSMA', category: 'chemicals', price20L: 'R 2,600.00', price5L: 'R 700.00', description: 'Post-emergence herbicide' },
      { id: 11, name: 'PARAQUART', category: 'chemicals', price20L: 'R 1,380.00', price5L: 'R 450.00', description: 'Fast-acting contact herbicide' },
      { id: 12, name: 'CLEAROUT', category: 'chemicals', price20L: 'R 1,600.00', price5L: 'R 450.00', description: 'Broad-spectrum weed control' },
      { id: 13, name: 'FARMURON', category: 'chemicals', price20L: 'R 2,500.00', price5L: 'R 850.00', description: 'Systemic herbicide solution' },
      { id: 14, name: 'GUILLOTINE', category: 'chemicals', pricePacket: 'R 130.00', priceBox: 'R 1,300.00', unitPacket: 'Packet of 50g', unitBox: 'Box of 10', description: 'Powerful herbicide treatment' }
    ];

    const filteredProducts = category === 'all' ? products : products.filter(p => p.category === category);

    return (
      <div className="min-h-screen" data-name="products-app" data-file="products-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-8 text-center">Our Products</h1>
            
            <div className="flex justify-center gap-4 mb-12">
              <button onClick={() => setCategory('all')} className={`px-6 py-2 rounded-lg font-semibold transition-all ${category === 'all' ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-200 text-[var(--text-dark)]'}`}>All Products</button>
              <button onClick={() => setCategory('fertilizers')} className={`px-6 py-2 rounded-lg font-semibold transition-all ${category === 'fertilizers' ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-200 text-[var(--text-dark)]'}`}>Fertilizers</button>
              <button onClick={() => setCategory('chemicals')} className={`px-6 py-2 rounded-lg font-semibold transition-all ${category === 'chemicals' ? 'bg-[var(--primary-color)] text-white' : 'bg-gray-200 text-[var(--text-dark)]'}`}>Chemicals</button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map(product => (
                <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                  {product.image && <img src={product.image} alt={product.name} className="w-full h-48 object-cover" />}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-[var(--primary-color)] mb-2">{product.name}</h3>
                    
                    {product.unit && <p className="text-sm text-[var(--text-light)] mb-3">{product.unit}</p>}
                    
                    <p className="text-[var(--text-light)] mb-4 text-sm">{product.description}</p>
                    
                    {product.price && (
                      <p className="text-2xl font-bold text-[var(--accent-color)] mb-4">{product.price}</p>
                    )}
                    
                    {product.price20L && (
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-[var(--text-light)]">20 Litres:</span>
                          <span className="text-lg font-bold text-[var(--accent-color)]">{product.price20L}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-[var(--text-light)]">5 Litres:</span>
                          <span className="text-lg font-bold text-[var(--accent-color)]">{product.price5L}</span>
                        </div>
                      </div>
                    )}
                    
                    {product.pricePacket && (
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-[var(--text-light)]">{product.unitPacket}:</span>
                          <span className="text-lg font-bold text-[var(--accent-color)]">{product.pricePacket}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-[var(--text-light)]">{product.unitBox}:</span>
                          <span className="text-lg font-bold text-[var(--accent-color)]">{product.priceBox}</span>
                        </div>
                      </div>
                    )}
                    
                    <button onClick={() => addToCart(product)} className="btn-primary w-full">Add to Order</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('ProductsApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><ProductsApp /></ErrorBoundary>);
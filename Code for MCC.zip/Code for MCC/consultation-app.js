class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="min-h-screen flex items-center justify-center bg-gray-50"><div className="text-center"><h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1><button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button></div></div>;
    }
    return this.props.children;
  }
}

function ConsultationApp() {
  try {
    const [formData, setFormData] = React.useState({name: '', phone: '', email: '', farm: '', farmSize: '', cropStage: '', concernArea: '', message: ''});
    const [submitted, setSubmitted] = React.useState(false);

    const handleSubmit = (e) => {
      e.preventDefault();
      
      const emailSubject = `Consultation Request from ${formData.name}`;
      const emailBody = `
New Consultation Request

Customer Details:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Email: ${formData.email || 'Not provided'}
- Farm Location: ${formData.farm}
- Farm Size: ${formData.farmSize || 'Not specified'}
- Crop Stage: ${formData.cropStage}
- Concern Area: ${formData.concernArea}

Consultation Request:
${formData.message}

Request Date: ${new Date().toLocaleString('en-ZA', { timeZone: 'Africa/Johannesburg' })}
      `.trim();
      
      const emailRecipients = [
        'mccfertilizers@gmail.com',
        'info@mccfertilizers.co.za',
        'francis.moyo1975@gmail.com'
      ];
      
      const mailtoLink = `mailto:${emailRecipients.join(',')}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.open(mailtoLink, '_blank');
      
      console.log('Consultation request submitted:', formData);
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    };

    const handleChange = (e) => {
      setFormData({...formData, [e.target.name]: e.target.value});
    };

    return (
      <div className="min-h-screen" data-name="consultation-app" data-file="consultation-app.js">
        <Header />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--primary-color)] mb-6 text-center">Request Expert Consultation</h1>
            <p className="text-lg text-[var(--text-light)] text-center mb-12">Get professional farming advice from our experienced agricultural consultants. We're here to help optimize your sugarcane cultivation.</p>
            
            {submitted && (
              <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">Consultation request submitted! Our expert will contact you shortly.</div>
            )}

            <form onSubmit={handleSubmit} className="bg-white shadow-lg rounded-lg p-8">
              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Full Name *</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Phone Number *</label>
                  <input type="tel" name="phone" value={formData.phone} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Email</label>
                  <input type="email" name="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Location *</label>
                  <input type="text" name="farm" value={formData.farm} onChange={handleChange} required placeholder="e.g., Empangeni, KZN" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
                <div>
                  <label className="block text-[var(--text-dark)] font-semibold mb-2">Farm Size (Hectares)</label>
                  <input type="text" name="farmSize" value={formData.farmSize} onChange={handleChange} placeholder="e.g., 50 hectares" className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Current Crop Stage *</label>
                <select name="cropStage" value={formData.cropStage} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]">
                  <option value="">Select stage</option>
                  <option value="Planting">Planting</option>
                  <option value="Early Growth">Early Growth</option>
                  <option value="Mid Growth">Mid Growth</option>
                  <option value="Maturity">Maturity</option>
                  <option value="Pre-Harvest">Pre-Harvest</option>
                  <option value="Post-Harvest">Post-Harvest</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Area of Concern *</label>
                <select name="concernArea" value={formData.concernArea} onChange={handleChange} required className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]">
                  <option value="">Select area</option>
                  <option value="Fertilization">Fertilization Program</option>
                  <option value="Pest Control">Pest Control</option>
                  <option value="Weed Management">Weed Management</option>
                  <option value="Disease Management">Disease Management</option>
                  <option value="Soil Health">Soil Health</option>
                  <option value="Yield Optimization">Yield Optimization</option>
                  <option value="General Advice">General Farming Advice</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-[var(--text-dark)] font-semibold mb-2">Describe Your Consultation Needs *</label>
                <textarea name="message" value={formData.message} onChange={handleChange} required rows="5" placeholder="Please describe the challenges you're facing or the advice you're seeking..." className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-[var(--primary-color)]"></textarea>
              </div>

              <button type="submit" className="btn-primary w-full">Request Consultation</button>
            </form>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('ConsultationApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><ConsultationApp /></ErrorBoundary>);
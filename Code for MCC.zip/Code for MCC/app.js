class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Something went wrong</h1>
            <p className="text-gray-600 mb-4">We're sorry, but something unexpected happened.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">Reload Page</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    return (
      <div className="min-h-screen" data-name="app" data-file="app.js">
        <Header />
        <HeroCarousel />
        
        <section className="py-16 px-4 bg-white">
          <div className="max-w-6xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-[var(--primary-color)] mb-6">
              Your Trusted Partner in Sugarcane Farming
            </h2>
            <p className="text-lg text-[var(--text-light)] mb-8 max-w-3xl mx-auto">
              MCC Fertilizers specializes in supplying premium fertilizers and chemicals exclusively for sugarcane farming throughout KwaZulu-Natal. With deep local expertise and commitment to your success, we provide the products and advice you need to maximize your harvest.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="products.html" className="btn-primary">View Products</a>
              <a href="consultation.html" className="btn-secondary">Request Consultation</a>
            </div>
          </div>
        </section>

        <section className="py-16 px-4 bg-[var(--bg-light)]">
          <div className="max-w-6xl mx-auto">
            <h3 className="text-2xl md:text-3xl font-bold text-center text-[var(--primary-color)] mb-12">
              What We Offer
            </h3>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--secondary-color)] flex items-center justify-center">
                  <div className="icon-leaf text-2xl text-white"></div>
                </div>
                <h4 className="text-xl font-bold mb-2">Quality Fertilizers</h4>
                <p className="text-[var(--text-light)]">Premium fertilizers designed specifically for sugarcane cultivation</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--secondary-color)] flex items-center justify-center">
                  <div className="icon-droplet text-2xl text-white"></div>
                </div>
                <h4 className="text-xl font-bold mb-2">Agricultural Chemicals</h4>
                <p className="text-[var(--text-light)]">Effective chemical solutions for crop protection and growth</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[var(--secondary-color)] flex items-center justify-center">
                  <div className="icon-users text-2xl text-white"></div>
                </div>
                <h4 className="text-xl font-bold mb-2">Expert Advice</h4>
                <p className="text-[var(--text-light)]">Professional farming consultation and ongoing support</p>
              </div>
            </div>
          </div>
        </section>

        <Footer />
        <WhatsAppButton />
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
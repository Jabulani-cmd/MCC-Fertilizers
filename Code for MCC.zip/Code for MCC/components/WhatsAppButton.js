function WhatsAppButton() {
  try {
    const whatsappNumber = '27764206125';
    const message = 'Hello MCC Fertilizers, I would like to inquire about your products.';
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

    return (
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 w-16 h-16 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-lg transition-all z-50"
        data-name="whatsapp-button"
        data-file="components/WhatsAppButton.js"
      >
        <div className="icon-message-circle text-3xl text-white"></div>
      </a>
    );
  } catch (error) {
    console.error('WhatsAppButton component error:', error);
    return null;
  }
}
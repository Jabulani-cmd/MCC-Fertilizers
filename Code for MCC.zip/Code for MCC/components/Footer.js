function Footer() {
  try {
    return (
      <footer className="bg-[var(--primary-color)] text-white py-12 px-4" data-name="footer" data-file="components/Footer.js">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8">
          <div>
            <h4 className="text-xl font-bold mb-4">MCC Fertilizers</h4>
            <p className="text-gray-200 mb-4">Your trusted partner for sugarcane farming solutions in KwaZulu-Natal.</p>
          </div>
          
          <div>
            <h4 className="text-xl font-bold mb-4">Quick Links</h4>
            <div className="space-y-2">
              <a href="index.html" className="block text-gray-200 hover:text-white">Home</a>
              <a href="about.html" className="block text-gray-200 hover:text-white">About Us</a>
              <a href="why-us.html" className="block text-gray-200 hover:text-white">Why Us</a>
              <a href="products.html" className="block text-gray-200 hover:text-white">Products</a>
              <a href="place-order.html" className="block text-gray-200 hover:text-white">Place Order</a>
              <a href="contact.html" className="block text-gray-200 hover:text-white">Contact Us</a>
            </div>
          </div>
          
          <div>
            <h4 className="text-xl font-bold mb-4">Contact Info</h4>
            <div className="space-y-2 text-gray-200">
              <div className="flex items-start">
                <div className="icon-map-pin text-lg mr-2 mt-1"></div>
                <span>UMoba House, 1 Blesbok Street, Empangeni Rail 3910, KZN</span>
              </div>
              <div className="flex items-center">
                <div className="icon-phone text-lg mr-2"></div>
                <span>+27 35 772 1205</span>
              </div>
              <div className="flex items-center">
                <div className="icon-mail text-lg mr-2"></div>
                <span>info@mccfertilizers.co.za</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="max-w-6xl mx-auto mt-8 pt-8 border-t border-gray-600 text-center text-gray-300">
          <p>&copy; 2025 MCC Fertilizers. All rights reserved.</p>
        </div>
      </footer>
    );
  } catch (error) {
    console.error('Footer component error:', error);
    return null;
  }
}
function Header() {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    return (
      <header className="bg-white shadow-md sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 py-2">
          <div className="flex justify-between items-center">
            <a href="index.html" className="flex items-center">
              <img src="https://app.trickle.so/storage/tasks/storage/generated_images/1764827705711.png" alt="MCC Fertilizers" className="h-32 w-auto object-contain" />
            </a>

            <button 
              className="md:hidden text-[var(--primary-color)]"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-2xl`}></div>
            </button>

            <nav className="hidden md:flex space-x-6">
              <a href="index.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Home</a>
              <a href="about.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">About Us</a>
              <a href="why-us.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Why Us</a>
              <a href="products.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Products</a>
              <a href="place-order.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Place Order</a>
              <a href="request-quote.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Request a Quote</a>
              <a href="contact.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Contact Us</a>
            </nav>
          </div>

          {isMenuOpen && (
            <nav className="md:hidden mt-4 pb-4 flex flex-col space-y-3">
              <a href="index.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Home</a>
              <a href="about.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">About Us</a>
              <a href="why-us.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Why Us</a>
              <a href="products.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Products</a>
              <a href="place-order.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Place Order</a>
              <a href="request-quote.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Request a Quote</a>
              <a href="contact.html" className="text-[var(--text-dark)] hover:text-[var(--primary-color)] font-medium">Contact Us</a>
            </nav>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}
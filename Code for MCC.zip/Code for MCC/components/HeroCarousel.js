function HeroCarousel() {
  try {
    const [currentSlide, setCurrentSlide] = React.useState(0);
    
    const slides = [
      {
        image: 'https://eos.com/wp-content/uploads/2022/11/growing-sugar-cane.jpg.webp',
        title: 'Premium Sugarcane Solutions',
        subtitle: 'Quality fertilizers for optimal growth and healthy crops'
      },
      {
        image: 'https://cdn.britannica.com/16/110316-050-07BD9B2B/cutting-machine-plantation-harvesting-sugarcane-ethanol-biofuel.jpg',
        title: 'Modern Farming Excellence',
        subtitle: 'Supporting your harvest from planting to harvest'
      },
      {
        image: 'https://app.trickle.so/storage/public/images/usr_172cb91f60000001/1d1be73c-06f7-41ea-8462-4051d6bbc0cd.png',
        title: 'Professional Chemical Solutions',
        subtitle: 'Expert products for effective crop protection'
      },
      {
        image: 'https://app.trickle.so/storage/public/images/usr_172cb91f60000001/96610f9a-819f-4835-92f3-bad93eb20309.png',
        title: 'Trusted by KZN Farmers',
        subtitle: 'Serving the sugarcane industry with excellence'
      }
    ];

    React.useEffect(() => {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      }, 5000);
      return () => clearInterval(timer);
    }, []);

    const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
    const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

    return (
      <div className="relative h-[500px] overflow-hidden" data-name="hero-carousel" data-file="components/HeroCarousel.js">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
            style={{backgroundImage: `url(${slide.image})`, backgroundSize: 'cover', backgroundPosition: 'center'}}
          >
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="text-center text-white px-4">
                <h1 className="text-4xl md:text-6xl font-bold mb-4">{slide.title}</h1>
                <p className="text-xl md:text-2xl">{slide.subtitle}</p>
              </div>
            </div>
          </div>
        ))}
        
        <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-30 hover:bg-opacity-50 text-white p-3 rounded-full">
          <div className="icon-chevron-left text-2xl"></div>
        </button>
        <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-30 hover:bg-opacity-50 text-white p-3 rounded-full">
          <div className="icon-chevron-right text-2xl"></div>
        </button>
      </div>
    );
  } catch (error) {
    console.error('HeroCarousel component error:', error);
    return null;
  }
}